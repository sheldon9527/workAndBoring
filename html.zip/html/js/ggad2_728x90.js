﻿document.writeln("<link type=\'text/css\' rel=\'stylesheet\' href=\'http://www.cssmoban.com/statics/css/astyle.css\' />");
document.writeln("<div align=\'center\'");
document.writeln("<a href=\'http://www.qifeiye.com/%E5%93%8D%E5%BA%94%E5%BC%8F%E7%BD%91%E7%AB%99%E6%A8%A1%E6%9D%BF-%E5%93%8D%E5%BA%94%E5%BC%8F%E6%A8%A1%E6%9D%BF-h5%E6%A8%A1%E6%9D%BF/?refercc=96521c4d83e995dab2d2faa0dfaa4519\' rel=\'nofollow\' target=\'_blank\'><img src=\'http://\' title=\'起飞页网站设计\' alt=\'起飞页网站设计\' border=\'0\' height=\'90\' width=\'970\'></a>");
document.writeln("</div>");